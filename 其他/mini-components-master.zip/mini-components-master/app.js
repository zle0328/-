//app.js
import page from './utils/page';
App({
    onLaunch: function() {
        Page = page;
    },
    globalData: {}
})