//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
  },
  
  onLoad: function () {
    
  },
  back: function(e){
      console.log(e.detail.back)
  }
})
