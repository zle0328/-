# uni-app 代码块（vscode）

将代码块文件放入项目下的 .vscode 目录，即可拥有和 HBuilderX 一样的代码块。

![](https://img-cdn-qiniu.dcloud.net.cn/uploads/article/20190827/870c114c199a93beedac79a78dde5f02.png)

![](https://img-cdn-qiniu.dcloud.net.cn/uploads/article/20190827/ff0d8b9c1edd6f002657d20021def9be.png)
